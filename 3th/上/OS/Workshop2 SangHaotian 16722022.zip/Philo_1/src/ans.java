/*This class uses taking the right and left forks at same time to arrange the sequence of dinner.*/
import java.util.concurrent.Semaphore;

public class ans extends Thread {

	int i = 0;
	private Fork fork;

	public ans(int i, Fork fork) {
		this.i = i;
		this.fork = fork;
	}

	/*Implement the run() method*/
	public void run() {
		while (true) {
			for(;i<5;i++) {
				think();
				fork.takeFork(i);
				eat();
				fork.putFork(i);
			}
		}
	}
	
	/*This method is built for thinking*/
	public void think() {
		System.out.println("Thinking:" + Thread.currentThread().getName());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*This method is built for eating*/
	public void eat() {
		System.out.println("Eating:" + Thread.currentThread().getName());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

/*This class is used to build a set of fork*/
class Fork {
	boolean fork[] = { false, false, false, false, false }; // Set the judge value
	int n = 5;

	/*This method is built for philosopher taking forks */
	public synchronized void takeFork(int i) {
		while (fork[i] || fork[(i + 1) % n]) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		fork[i] = true;
		fork[(i + 1) % n] = true;
	}
	
	/*This method is built for philosopher put back forks */
	public synchronized void putFork(int i) {
		fork[i] = false;
		fork[(i + 1) % n] = false;
		notifyAll();
	}
}
