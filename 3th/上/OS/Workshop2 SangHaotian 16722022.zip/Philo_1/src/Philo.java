
public class Philo extends Thread{
	public static void main(String []args){
		Fork fork = new Fork();
        new ans(0,fork).start();
        new ans(1,fork).start();
        new ans(2,fork).start();
        new ans(3,fork).start();
        new ans(4,fork).start();
    }
}
