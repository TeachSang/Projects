
public class philo extends Thread{
	public static void main(String []args){
		Fork fork = new Fork();
        new ans_3(0,fork).start();
        new ans_3(1,fork).start();
        new ans_3(2,fork).start();
        new ans_3(3,fork).start();
        new ans_3(4,fork).start();
    }
}
