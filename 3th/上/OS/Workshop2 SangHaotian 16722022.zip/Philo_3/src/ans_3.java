
/*This class using  odd philosopher eat first, even philosopher eat later to arrange the sequence of dinner.*/

import java.util.concurrent.Semaphore;

public class ans_3 extends Thread {
	// Semaphore mutex = new Semaphore(1);
	int i = 0, n = 0;
	private Fork fork;

	public ans_3(int i, Fork fork) {
		this.i = i;
		this.fork = fork;
	}

	/* Implement the run() method */
	public void run() {
		while (true) {
			String a;
			int b = 0;
			a = Thread.currentThread().getName();
			a = a.substring(a.length() - 1);
			try {
				b = Integer.parseInt(a);
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
			// System.out.println(b);
			if (b % 2 == 0) {
				think();
				fork.takeFork(i + 1);
				eat();
				fork.putFork(i + 1);
				think();
				fork.takeFork(i);
				eat();
				fork.putFork(i);

			} else {
				think();
				fork.takeFork(i);
				eat();
				fork.putFork(i);
				think();
				fork.takeFork(i + 1);
				eat();
				fork.putFork(i + 1);

			}
		}
	}

	/* This method is built for thinking */
	public void think() {
		System.out.println("Thinking:" + Thread.currentThread().getName());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/* This method is built for eating */
	public void eat() {
		System.out.println("Eating:" + Thread.currentThread().getName());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

/* This class is used to build a set of fork */
class Fork {
	boolean fork[] = { false, false, false, false, false }; // Set the judge value
	int n = 5;

	/* This method is built for philosopher taking forks */
	public synchronized void takeFork(int i) {
		if (i < 5) {
			while (fork[i] || fork[(i + 1) % n]) {
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			fork[i] = true;
			fork[(i + 1) % n] = true;
		}
	}

	/* This method is built for philosopher put back forks */
	public synchronized void putFork(int i) {
		if (i < 5) {
			fork[i] = false;
			fork[(i + 1) % n] = false;
			notifyAll();
		}
	}

	/*
	 * public synchronized void waitFork() { try { wait(); } catch
	 * (InterruptedException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } }
	 */

	/*
	 * public synchronized void cleanFork() { for (int j = 0; j < 5; j++) { fork[j]
	 * = false; } notifyAll(); }
	 */
}
