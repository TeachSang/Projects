
public class test {
	public static void main(String args[]) {
		Money m = new Money();
		for (int i = 0; i < 10; i++) {
			if(i % 2 == 0) {
				new Thread(new Producer(m)).start();
				//System.out.println("0");
			} else {
				new Thread(new Customer(m)).start();
				//System.out.println("1");
			}
		}
    }
}
