/*This class is used to realized Customer operation*/
public class Customer implements Runnable {
	private Money m;

	public Customer(Money m) {
		this.m = m;
	}
	
	
	
	/*Implement the run() method*/
	public void run() {
		while (true) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			m.consume();
		}
	}
}
