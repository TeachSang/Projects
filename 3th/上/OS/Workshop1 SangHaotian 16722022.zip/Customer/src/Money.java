
public class Money {
	private int money = 0;
	private boolean flag = false;

	/*This method is used to build Producer*/
	public synchronized void produce() {
		while (flag) { /*Judge it weather be used*/
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (money < 10) {
			money++;/*To add money if it in the range of request*/
		}
		System.out.println(Thread.currentThread().getName() + " money is: " + money);
		flag = true;
		notifyAll();
	}
	
	/*This method is used to build consumer*/
	public synchronized void consume() {
		while (!flag) { /*Judge it weather be used*/
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if (money >= 0) {
			money--;/*To reduce money if it in the range of request*/
		}
		System.out.println(Thread.currentThread().getName() + " money is: " + money);
		flag = false;
		notifyAll();
	}
}
