/*This class is used to realized Producer operation*/
public class Producer implements Runnable {
	private Money m;

	public Producer(Money m) {
		this.m = m;
	}
	
	/*Implement the run() method*/
	public void run() {
		while (true) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			m.produce();
		}
	}

}
