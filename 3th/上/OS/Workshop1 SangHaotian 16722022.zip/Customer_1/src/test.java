
public class test {
	public static void main(String[] args) {
		customer_1 customer = new customer_1();
		for (int i = 0; i < 10; i++) {
			if (i % 2 == 0) {	
				new Thread(new P(customer)).start();
			} else {
				new Thread(new V(customer)).start();
			}
		}
	}
}
