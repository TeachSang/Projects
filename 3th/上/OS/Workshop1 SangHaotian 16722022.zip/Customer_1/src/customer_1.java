
public class customer_1{
	private int money = 0;
	
	/*This method is used to build Producer*/
	public synchronized void P() {
		/*Judge the range*/
		while(money>=10) {
			try {
				//System.out.println("waiting");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}            
		}
		money++; /*To add money if it in the range of request*/
		System.out.println(Thread.currentThread().getName()+" money is: "+ money);
		notifyAll();
	}
	
	/*This method is used to build consumer*/
	public synchronized void V() {
		/*Judge the range*/
		while(money<=0) {
			try {
				//System.out.println("waiting");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		money--; /*To reduce money if it in the range of request*/
		System.out.println(Thread.currentThread().getName()+" money is: "+ money);
		notifyAll();
	}
}
