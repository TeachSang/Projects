/*This class is used to realized Producer operation*/
public class P implements Runnable{
	private customer_1 m;

	public P(customer_1 m) {
		this.m = m;
	}
	
	/*Implement the run() method*/
	public void run() {
		while (true) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			m.P();
		}
	}
}
