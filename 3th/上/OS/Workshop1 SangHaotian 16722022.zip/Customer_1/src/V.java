/*This class is used to realized Customer operation*/
public class V implements Runnable{
	private customer_1 m;

	public V(customer_1 m) {
		this.m = m;
	}
	
	/*Implement the run() method*/
	public void run() {
		while (true) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			m.V();
		}
	}
}
