import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;

public class GameOver extends JFrame implements ActionListener
{
    private JPanel welcomePanel = new JPanel();
    private JLabel title = new JLabel("Game Over!",SwingConstants.CENTER);
    JButton over = new JButton("Close All Windows");
    //创建一个按钮组

    public void over()
    {
        Font font = new Font("Arial", Font.BOLD, 20);

        title.setFont(new Font("Arial", Font.BOLD, 28));
        over.setFont(new Font("Consolas", Font.BOLD, 20));

        title.setForeground(new Color(139,0,0));
        title.setBackground(new Color(255,228,225));
        title.setOpaque(true);

        //将按钮按列排列
        welcomePanel.setBackground(new Color(255,255,205));

        welcomePanel.add(over,BorderLayout.CENTER);

        this.add(title,BorderLayout.NORTH);
        this.add(welcomePanel);
        this.setTitle("Over");
        this.setSize(400,150);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.repaint();

        //监听确认按钮
        over.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    System.exit(0);
                }
            });
    }

    public void actionPerformed(ActionEvent e)
    {
    }
}
