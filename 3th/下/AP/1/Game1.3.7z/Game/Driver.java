import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;

public class Driver extends JFrame implements ActionListener
{
    private JPanel welcomePanel = new JPanel();
    private JLabel title = new JLabel("Welcome to the game!",SwingConstants.CENTER);
    JButton start = new JButton("START");
    //创建一个按钮组
    ButtonGroup option= new ButtonGroup();
    JRadioButton easy = new JRadioButton("Easy  ");
    JRadioButton normal = new JRadioButton("Normal  ");
    JRadioButton hard = new JRadioButton("Hard      ");
    public void welcome()
    {
        Font font = new Font("Arial", Font.BOLD, 20);
        
        title.setFont(new Font("Arial", Font.BOLD, 28));
        easy.setFont(font);
        normal.setFont(font);
        hard.setFont(font);
        start.setFont(new Font("Consolas", Font.BOLD, 20));
        
        title.setForeground(new Color(139,0,0));
        title.setBackground(new Color(255,228,225));
        title.setOpaque(true);
        easy.setBackground(new Color(255,255,205));
        normal.setBackground(new Color(255,255,205));
        hard.setBackground(new Color(255,255,205));
        
        //把按钮加到同一个按钮组
        option.add(easy);
        option.add(normal);
        option.add(hard);

        //将按钮按列排列
        welcomePanel.setLayout(new BoxLayout(welcomePanel,BoxLayout.X_AXIS));
        welcomePanel.setBackground(new Color(255,255,205));

        welcomePanel.add(easy);
        welcomePanel.add(normal);
        welcomePanel.add(hard);
        welcomePanel.add(start);
        //设置边框
        welcomePanel.setBorder(BorderFactory.createTitledBorder("Choose the suitable level and click START (Default Normal difficulty)"));

        this.add(title,BorderLayout.NORTH);
        this.add(welcomePanel);
        this.setTitle("Welcome");
        this.setSize(420,200);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.repaint();

        //监听确认按钮
        start.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    if(easy.isSelected() == true)
                    {
                        GameBoard b = new GameBoard("BombSweeper", 20,20);
                    }
                    else if(normal.isSelected() == true)
                    {
                        GameBoard b = new GameBoard("BombSweeper", 25,25);
                    }
                    else if(hard.isSelected() == true)
                    {
                        GameBoard b = new GameBoard("BombSweeper", 30,30);
                    }
                    else            //没有选按钮便提交
                    {
                        GameBoard b = new GameBoard("BombSweeper", 25,25);
                    }
                    //点击确认按钮后，改变题目的值
                    setVisible(false);
                    //重置按钮的值
                    option.clearSelection();
                }
            });
    }

    public static void main(String[] Args)
    {
        //GameBoard b = new GameBoard("BombSweeper", 20,20);
        Driver driver = new Driver();
        driver.welcome();
    }

    public void actionPerformed(ActionEvent e)
    {
        // The button that has been pressed.
        
    }
}
