import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;
/**
 * This class provides a graphical model of a board game.
 * The class creates a rectangular panel of clickable squares,
 * of type SmartSquare. If a square is clicked by the user, a
 * callback method is invoked upon the corresponding SmartSquare instance.
 * The class is intended to be used as a basis for tile based games.
 * @author joe finney
 */
public class GameBoard extends JFrame implements ActionListener
{
    private JFrame frame = new JFrame();
    private JPanel titlePanel = new JPanel();
    private JPanel boardPanel = new JPanel();
    private JPanel downPanel = new JPanel();

    private int boardHeight;
    private int boardWidth;
    private GameSquare[][] board; 

    JLabel calTime = new JLabel();
    JButton restart = new JButton("Restart");
    JLabel rules = new JLabel("Game rules");
    JComboBox level =new JComboBox();

    /**
     * Create a new game board of the given size.
     * As soon as an instance of this class is created, it is visualized
     * on the screen.
     * 
     * @param title the name printed in the window bar.
     * @param width the width of the game area, in squares.
     * @param height the height of the game area, in squares.
     */
    public GameBoard(String title, int width, int height)
    {
        super();

        this.boardWidth = width;
        this.boardHeight = height;

        this.buildGame(width,height);
    }

    public void buildGame(int width,int height){
        // Create game state
        board = new GameSquare[width][height];

        frame.setLayout(new BorderLayout(5,5));
        // Set up window
        frame.setTitle("Game");
        frame.setSize(20+width*21,80+height*21);
        //setContentPane(boardPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        boardPanel.setLayout(new GridLayout(height,width));
        boardPanel.setBackground(new Color(245,255,250));

        buttons();
        mainMenu(height,width);
        frame.add("Center", boardPanel);

        // make our window visible
        //frame.pack(); 255,240,245
        frame.setVisible(true); 
    }
    
    public void mainMenu(int height, int width){
        boardPanel.removeAll();
        for (int y = 0; y<height; y++)
        {
            for (int x = 0; x<width; x++)
            {
                board[x][y] = new SmartSquare(x, y, this);
                board[x][y].addActionListener(this);

                boardPanel.add(board[x][y]);
            }
        }
    }
        
    public void buttons() {
        //背景
        downPanel.setLayout(new FlowLayout());
        downPanel.setBackground(new Color(255,228,225));
        titlePanel.setLayout(new FlowLayout());
        titlePanel.setBackground(new Color(250,250,210));
        Font font = new Font("Arial", Font.BOLD, 18);

        //时间
        calTime.setFont(font);
        Timer timer = new Timer();
        TimerTask task=new TimerTask() {
                public void run() {
                    Date date = new Date();
                    String t = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
                    calTime.setText("Time is: "+t+"    ");
                }
            };
        //立即开始任务，任务间隔1000ms。schedule和scheduleAtFixedRate的区别自行搜索
        timer.scheduleAtFixedRate(task,0,1000);
        //重新开始
        restart.setFont(font);
        restart.setOpaque(false); //透明度
        restart.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    mainMenu(boardWidth,boardHeight);
                }
            });

        //加载分数面板
        rules.setFont(font);
        rules.setEnabled(false);
        rules.setOpaque(true); //透明度
        rules.addMouseMotionListener(new MouseAdapter(){
                public void mouseMoved(MouseEvent e) {
                    rules.setToolTipText("<html>1.Click to choose the square;<br>2.If you choose bomb, game over");
                }
            });

        //难度
        level.setFont(font);
        level.addItem("Level");
        level.addItem("Easy");
        level.addItem("Normal");
        level.addItem("Hard");
        level.addItemListener(new ItemListener(){
                public void itemStateChanged(ItemEvent e) {
                    frame.setVisible(false);
                    if(e.getItem().equals("Easy"))
                    {
                        GameBoard newA = new GameBoard("BombSweeper", 20,20);
                    }else if(e.getItem().equals("Normal")){
                        GameBoard newB = new GameBoard("BombSweeper", 25,25);
                    }else if(e.getItem().equals("Hard")){
                        GameBoard newC = new GameBoard("BombSweeper", 30,30);
                    }
                }
            });

        //加入
        titlePanel.add(level);
        titlePanel.add(restart);

        downPanel.add(calTime);
        downPanel.add(rules);

        frame.add("North", titlePanel);
        frame.add("South", downPanel);
    }

    /**
     * Returns the GameSquare instance at a given location. 
     * @param x the x co-ordinate of the square requested.
     * @param y the y co-ordinate of the square requested.
     * @return the GameSquare instance at a given location 
     * if the x and y co-ordinates are valid - null otherwise. 
     */
    public GameSquare getSquareAt(int x, int y)
    {
        if (x < 0 || x >= boardWidth || y < 0 || y >= boardHeight)
            return null;

        return board[x][y];
    }

    public void actionPerformed(ActionEvent e)
    {
        // The button that has been pressed.
        GameSquare b = (GameSquare)e.getSource();
        b.clicked();
    }

    public int getHeight()
    {
        return boardHeight;
    }

    public int getWidth()
    {
        return boardWidth;
    }
}
