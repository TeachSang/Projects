import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
/**
 * This class provides a graphical model of a board game.
 * The class creates a rectangular panel of clickable squares,
 * of type SmartSquare. If a square is clicked by the user, a
 * callback method is invoked upon the corresponding SmartSquare instance.
 * The class is intended to be used as a basis for tile based games.
 * @author joe finney
 */
public class GameBoard extends JFrame implements ActionListener
{
    private JFrame frame = new JFrame();
    private JPanel titlePanel = new JPanel();
    private JPanel boardPanel = new JPanel();
    private JPanel downPanel = new JPanel();

    private int boardHeight;
    private int boardWidth;
    private GameSquare[][] board; 
    private int allTime;
    private int allScore;
        
    JLabel calTime = new JLabel("Time:" + allTime);
    JButton restart = new JButton("Restart" + allScore);
    JLabel score = new JLabel("Score:");
    JComboBox level =new JComboBox();

    /**
     * Create a new game board of the given size.
     * As soon as an instance of this class is created, it is visualized
     * on the screen.
     * 
     * @param title the name printed in the window bar.
     * @param width the width of the game area, in squares.
     * @param height the height of the game area, in squares.
     */
    public GameBoard(String title, int width, int height)
    {
        super();

        this.boardWidth = width;
        this.boardHeight = height;

        // Create game state
        this.board = new GameSquare[width][height];

        frame.setLayout(new BorderLayout(5,5));
        // Set up window
        frame.setTitle(title);
        frame.setSize(20+width*20,80+height*20);
        //setContentPane(boardPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        boardPanel.setLayout(new GridLayout(height,width));

        buttons();

        for (int y = 0; y<height; y++)
        {
            for (int x = 0; x<width; x++)
            {
                board[x][y] = new SmartSquare(x, y, this);
                board[x][y].addActionListener(this);

                boardPanel.add(board[x][y]);
            }
        }
        frame.add("Center", boardPanel);
        // make our window visible
        //frame.pack(); 255,240,245
        frame.setVisible(true);  
    }

    public void buttons() {
        //背景
        downPanel.setLayout(new FlowLayout());
        downPanel.setBackground(new Color(255,240,245));
        titlePanel.setLayout(new FlowLayout());
        titlePanel.setBackground(new Color(250,250,210));
        Font font = new Font("Arial", Font.BOLD, 12);

        //时间
        calTime.setFont(font);
        
        //重新开始
        restart.setFont(font);
        restart.setOpaque(false); //透明度
        restart.addActionListener(this);

        //加载分数面板
        score.setFont(font);
        score.setEnabled(false);
        score.setOpaque(true); //透明度
        
        //难度
        level.addItem("Easy");
        level.addItem("Normal");
        level.addItem("Hard");
        
        //加入
        titlePanel.add(level);
        titlePanel.add(restart);
        downPanel.add(calTime);
        downPanel.add(score);

        frame.add("North", titlePanel);
        frame.add("South", downPanel);
    }

    /**
     * Returns the GameSquare instance at a given location. 
     * @param x the x co-ordinate of the square requested.
     * @param y the y co-ordinate of the square requested.
     * @return the GameSquare instance at a given location 
     * if the x and y co-ordinates are valid - null otherwise. 
     */
    public GameSquare getSquareAt(int x, int y)
    {
        if (x < 0 || x >= boardWidth || y < 0 || y >= boardHeight)
            return null;

        return board[x][y];
    }

    public void actionPerformed(ActionEvent e)
    {
        // The button that has been pressed.
        GameSquare b = (GameSquare)e.getSource();
        b.clicked();
    }

    public int getHeight()
    {
        return boardHeight;
    }
    
    public int getWidth()
    {
        return boardWidth;
    }
    
    public int getTime()
    {
        return boardWidth;
    }
    
    public int getScore()
    {
        return boardWidth;
    }
}
