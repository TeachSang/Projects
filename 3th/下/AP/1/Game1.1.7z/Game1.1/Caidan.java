
/**
 * 在这里给出对类 Caidan 的描述。
 * 
 * @作者（你的名字）
 * @版本（一个版本号或者一个日期）
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Caidan extends JFrame
{
    JPanel caidan = new JPanel();
    JLabel surpise=new JLabel();
    JLabel words=new JLabel("Don't click this button!!!");
    
    private static Thread t;
    private int count=10;
    private Container con=getContentPane();
    
    ImageIcon picture = new ImageIcon();
    
    public Caidan(){
        setBounds(400,200,500,300);
        
        words.setFont(new java.awt.Font("Arial", 1, 24));
        
        caidan.add("South",surpise);
        caidan.add("North", words);
        
        picture = new ImageIcon("D:/java/RiverCrossingGraphics/biaoqingbao1.jpg");
        surpise.setBounds(50,50,120,100);
        Image t1 = picture.getImage().getScaledInstance(surpise.getWidth(), surpise.getHeight(), picture.getImage().SCALE_DEFAULT);
        picture = new ImageIcon(t1);
        surpise.setIcon(picture);
        surpise.setHorizontalAlignment(SwingConstants.LEFT);
        
        surpise.setOpaque(true);
        t=new Thread(new Runnable() {
                public void run() {
                    while(count<500){
                        surpise.setBounds(count, 100, 200, 130);
                        try{
                            t.sleep(100);
                        }catch (Exception e) {
                            e.printStackTrace();
                        }
                        count+=10;
                        if(count==500){
                            count=10;
                        }
                    }
                }
            });
        t.start();
        con.add(surpise);
        setVisible(true);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        
        add(caidan);
    }

    public static void main(String args[]){
        new Caidan();
    }
}