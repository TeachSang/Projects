public class Driver
{
    public static void main(String[] Args)
    {
        GameBoard b = new GameBoard("BombSweeper", 20,20);
    }
}
