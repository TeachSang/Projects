import javax.swing.*;
import java.awt.*;
import java.util.*;

public class SmartSquare extends GameSquare
{
    private boolean thisSquareHasBomb = false;
    public static final int MINE_PROBABILITY = 10;
    private boolean checked = false;
    SmartSquare[] k=new SmartSquare[8];

    public SmartSquare(int x, int y, GameBoard board)
    {
        super(x, y, "images/blank.png", board);

        Random r = new Random();
        thisSquareHasBomb = (r.nextInt(MINE_PROBABILITY) == 0);
    }

    public void clicked()
    {   
        if(!this.thisSquareHasBomb)
        {
            this.judgement();
        }
        else
        {
            this.setIcon(new ImageIcon("images/bomb.png")); 
            showAll();
        }
    }

    public void showAll()
    {
        for(int n=0; n<board.getWidth(); n++){
            for(int m=0; m<board.getHeight(); m++){
                //System.out.println(n + "," + m);
                if(!((SmartSquare)board.getSquareAt(n,m)).thisSquareHasBomb)
                {
                    ((SmartSquare)board.getSquareAt(n,m)).setIcon(new ImageIcon("images/0.png"));
                }
                else
                {
                    ((SmartSquare)board.getSquareAt(n,m)).setIcon(new ImageIcon("images/bomb.png")); 
                }
            }
        }
    }

    public void judgement()
    {
        int i = 0;
        int a = super.xLocation;
        int b = super.yLocation;

        //System.out.println("("+super.xLocation+", "+super.yLocation+") "+this.checked);
        this.checked = true;
        //System.out.println("---------------------------------------------");

        k[0]=(SmartSquare)board.getSquareAt(a-1,b-1);
        k[1]=(SmartSquare)board.getSquareAt(a,b-1);
        k[2]=(SmartSquare)board.getSquareAt(a+1,b-1);
        k[3]=(SmartSquare)board.getSquareAt(a-1,b);
        k[4]=(SmartSquare)board.getSquareAt(a+1,b);
        k[5]=(SmartSquare)board.getSquareAt(a-1,b+1);
        k[6]=(SmartSquare)board.getSquareAt(a,b+1);
        k[7]=(SmartSquare)board.getSquareAt(a+1,b+1);

        for(int n=0; n<8; n++){
            if(k[n]!=null){
                if(k[n].thisSquareHasBomb)
                {
                    i++;
                }
            }
        }

        //System.out.println("("+super.xLocation+", "+super.yLocation+") "+this.checked);
        show(i);

        if(i==0){
            for(int j=0;j<8;j++)
            {
                if(k[j]!=null){
                    if(!k[j].checked)
                    {
                        k[j].judgement();
                        //System.out.println(k[j]);
                    }
                }
            }
        }
        //System.out.println("bye");
    }

    public void show(int m)
    {
        switch(m){
            case 0:
            this.setIcon(new ImageIcon("images/0.png"));
            break;
            case 1:
            this.setIcon(new ImageIcon("images/1.png"));
            break;
            case 2:
            this.setIcon(new ImageIcon("images/2.png"));
            break;
            case 3:
            this.setIcon(new ImageIcon("images/3.png"));
            break;
            case 4:
            this.setIcon(new ImageIcon("images/4.png"));
            break;
            case 5:
            this.setIcon(new ImageIcon("images/5.png"));
            break;
            case 6:
            this.setIcon(new ImageIcon("images/6.png"));
            break;
            case 7:
            this.setIcon(new ImageIcon("images/7.png"));
            break;
            case 8:
            this.setIcon(new ImageIcon("images/8.png"));
            break;
        }
    }
}
