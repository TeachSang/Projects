import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;


/** This class is used to build driver, 
 * which shows the 'Welcome' Interface and difficulity choosing Interface
 */
public class Driver extends JFrame
{
    private JPanel welcomePanel = new JPanel(); //Building the welcome panel
    private JLabel title = new JLabel("Welcome to the game!",SwingConstants.CENTER); //Building the title
    JButton start = new JButton("START"); //Build the start button
    
    //Building a group of buttons
    ButtonGroup group= new ButtonGroup();
    JRadioButton easy = new JRadioButton("Easy  ");
    JRadioButton normal = new JRadioButton("Normal  ");
    JRadioButton hard = new JRadioButton("Hard      ");
    public void welcome()
    {
        //Setting the font
        Font font = new Font("Arial", Font.BOLD, 20);
        title.setFont(new Font("Arial", Font.BOLD, 28));
        easy.setFont(font);
        normal.setFont(font);
        hard.setFont(font);
        start.setFont(new Font("Consolas", Font.BOLD, 20));
        
        //Setting the futures of title part
        title.setForeground(new Color(139,0,0));
        title.setBackground(new Color(255,228,225));
        title.setOpaque(true);
        //Setting the futures of buttons
        easy.setBackground(new Color(255,255,205));
        normal.setBackground(new Color(255,255,205));
        hard.setBackground(new Color(255,255,205));
        
        //Add buttons to the group
        group.add(easy);
        group.add(normal);
        group.add(hard);

        //Setting the layout of board
        welcomePanel.setLayout(new BoxLayout(welcomePanel,BoxLayout.X_AXIS));
        welcomePanel.setBackground(new Color(255,255,205));
        
        //Adding contents to the panel
        welcomePanel.add(easy);
        welcomePanel.add(normal);
        welcomePanel.add(hard);
        welcomePanel.add(start);
        //Setting the border contents
        welcomePanel.setBorder(BorderFactory.createTitledBorder("Choose the suitable level and click START (Default Normal difficulty)"));

        //Setting the Interface 
        this.add(title,BorderLayout.NORTH);
        this.add(welcomePanel);
        this.setTitle("Welcome");
        this.setSize(420,200);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.repaint();

        //Setting the START button when clicked
        start.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    if(easy.isSelected() == true) //Easy
                    {
                        GameBoard b = new GameBoard("BombSweeper", 20,20);
                    }
                    else if(normal.isSelected() == true) //Normal
                    {
                        GameBoard b = new GameBoard("BombSweeper", 25,25);
                    }
                    else if(hard.isSelected() == true) //Hard
                    {
                        GameBoard b = new GameBoard("BombSweeper", 30,30);
                    }
                    else            //The default difficulity
                    {
                        GameBoard b = new GameBoard("BombSweeper", 25,25);
                    }
                    //Close it after click
                    setVisible(false);
                    //Reset the groupButtons
                    group.clearSelection();
                }
            });
    }

    public static void main(String[] Args)
    {
        //Drive the game
        Driver driver = new Driver();
        driver.welcome();
    }
}
