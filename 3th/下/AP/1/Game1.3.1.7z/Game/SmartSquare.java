import javax.swing.*;
import java.awt.*;
import java.util.*;

public class SmartSquare extends GameSquare
{
    private boolean thisSquareHasBomb = false; //Check whether the square is bomb
    public static final int MINE_PROBABILITY = 10;
    private boolean checked = false; //Check whether the square is clicked
    SmartSquare[] k=new SmartSquare[8]; //Store the revelent 8 squares of a specific one

    /**Build the game chessboard and set the bomb*/
    public SmartSquare(int x, int y, GameBoard board)
    {
        super(x, y, "images/blank.png", board);

        Random r = new Random();
        thisSquareHasBomb = (r.nextInt(MINE_PROBABILITY) == 0);
    }
    
    /**Check the clicked square
     * If it's not bomb, check the surrounding 8 squares and show 
     * the amount of bombs. 
     * If it's bomb show all bombs and pop up the Ending interface
     */
    public void clicked()
    {   
        if(!this.thisSquareHasBomb)
        {
            this.judgement(); //Judge the surrunding 8 squares
        }
        else
        {
            this.setIcon(new ImageIcon("images/bomb.png")); 
            showAll(); //Show all bombs
            GameOver gameOver = new GameOver(); // Open the Ending interface
            gameOver.over();
        }
    }
    
    /**Show all bombs in the chessboard*/
    public void showAll()
    {
        for(int n=0; n<board.getWidth(); n++){
            for(int m=0; m<board.getHeight(); m++){
                //System.out.println(n + "," + m);
                if(!((SmartSquare)board.getSquareAt(n,m)).thisSquareHasBomb)
                {
                    ((SmartSquare)board.getSquareAt(n,m)).setIcon(new ImageIcon("images/0.png"));
                }
                else
                {
                    ((SmartSquare)board.getSquareAt(n,m)).setIcon(new ImageIcon("images/bomb.png")); 
                }
            }
        }
    }
    
    /**Judge the relevent 8 squares of the clicked square
     * If its 0, show all '0-squares' which surround it
     */
    public void judgement()
    {
        int i = 0;
        int a = super.xLocation;
        int b = super.yLocation;

        this.checked = true;
        //System.out.println("---------------------------------------------");
        
        //Put relevent 8 squares into arry
        k[0]=(SmartSquare)board.getSquareAt(a-1,b-1);
        k[1]=(SmartSquare)board.getSquareAt(a,b-1);
        k[2]=(SmartSquare)board.getSquareAt(a+1,b-1);
        k[3]=(SmartSquare)board.getSquareAt(a-1,b);
        k[4]=(SmartSquare)board.getSquareAt(a+1,b);
        k[5]=(SmartSquare)board.getSquareAt(a-1,b+1);
        k[6]=(SmartSquare)board.getSquareAt(a,b+1);
        k[7]=(SmartSquare)board.getSquareAt(a+1,b+1);

        //Calculate the amount of bombs
        for(int n=0; n<8; n++){
            if(k[n]!=null){
                if(k[n].thisSquareHasBomb)
                {
                    i++;
                }
            }
        }

        //Show the picture of corresponding number
        show(i);

        //If its 0, show all '0-squares' which surround it
        if(i==0){
            for(int j=0;j<8;j++)
            {
                if(k[j]!=null){
                    if(!k[j].checked)
                    {
                        k[j].judgement();
                    }
                }
            }
        }
    }

    /**Show the picture of corresponding number*/
    public void show(int m)
    {
        switch(m){
            case 0:
            this.setIcon(new ImageIcon("images/0.png"));
            break;
            case 1:
            this.setIcon(new ImageIcon("images/1.png"));
            break;
            case 2:
            this.setIcon(new ImageIcon("images/2.png"));
            break;
            case 3:
            this.setIcon(new ImageIcon("images/3.png"));
            break;
            case 4:
            this.setIcon(new ImageIcon("images/4.png"));
            break;
            case 5:
            this.setIcon(new ImageIcon("images/5.png"));
            break;
            case 6:
            this.setIcon(new ImageIcon("images/6.png"));
            break;
            case 7:
            this.setIcon(new ImageIcon("images/7.png"));
            break;
            case 8:
            this.setIcon(new ImageIcon("images/8.png"));
            break;
        }
    }
}
