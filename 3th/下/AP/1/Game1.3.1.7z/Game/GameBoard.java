import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;
/**
 * This class provides a graphical model of a board game.
 * The class creates a rectangular panel of clickable squares,
 * of type SmartSquare. If a square is clicked by the user, a
 * callback method is invoked upon the corresponding SmartSquare instance.
 * The class is intended to be used as a basis for tile based games.
 * @author joe finney
 */
public class GameBoard extends JFrame implements ActionListener
{
    //Create the structure of UI
    private JFrame frame = new JFrame();
    private JPanel titlePanel = new JPanel();
    private JPanel boardPanel = new JPanel();
    private JPanel downPanel = new JPanel();
    
    //Declare the varibles
    private int boardHeight;
    private int boardWidth;
    private GameSquare[][] board; 

    //Create the buttons and labels in the UI
    JLabel calTime = new JLabel();
    JButton restart = new JButton("Restart");
    JLabel rules = new JLabel("Game rules");
    JComboBox level =new JComboBox();

    /**
     * Create a new game board of the given size.
     * As soon as an instance of this class is created, it is visualized
     * on the screen.
     * 
     * @param title the name printed in the window bar.
     * @param width the width of the game area, in squares.
     * @param height the height of the game area, in squares.
     */
    public GameBoard(String title, int width, int height)
    {
        super();

        this.boardWidth = width;
        this.boardHeight = height;

        this.buildGame(width,height);
    }

    /**Create the the main board of game */
    public void buildGame(int width,int height){
        // Create game state
        board = new GameSquare[width][height];

        frame.setLayout(new BorderLayout(5,5));
        // Set up window
        frame.setTitle("Game");
        frame.setSize(20+width*21,80+height*21);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        boardPanel.setLayout(new GridLayout(height,width));
        boardPanel.setBackground(new Color(245,255,250));
        
        //Create the top and button panel and its' contents
        buttons();
        //Create the center panel
        mainMenu(height,width);
        frame.add("Center", boardPanel);

        // make our window visible
        //frame.pack(); 
        frame.setVisible(true); 
    }
    
    /**Create the central panel*/
    public void mainMenu(int height, int width){
        boardPanel.removeAll();
        for (int y = 0; y<height; y++)
        {
            for (int x = 0; x<width; x++)
            {
                board[x][y] = new SmartSquare(x, y, this);
                board[x][y].addActionListener(this);

                boardPanel.add(board[x][y]);
            }
        }
    }
    
    /**Create the top&buttom panel*/
    public void buttons() {
        //Seting the layout&Color of top & buttom parts
        downPanel.setLayout(new FlowLayout());
        downPanel.setBackground(new Color(255,228,225));
        titlePanel.setLayout(new FlowLayout());
        titlePanel.setBackground(new Color(250,250,210));
        
        Font font = new Font("Arial", Font.BOLD, 18); //Set the font

        //Set time calculator
        calTime.setFont(font);
        Timer timer = new Timer();
        TimerTask task=new TimerTask() {
                public void run() {
                    Date date = new Date();
                    String t = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
                    calTime.setText("Time is: "+t+"    ");
                }
            };
        timer.scheduleAtFixedRate(task,0,1000);
        
        //Set RESTART button
        restart.setFont(font);
        restart.setOpaque(false); 
        restart.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    mainMenu(boardWidth,boardHeight);
                }
            });

        //Set rules introduction part
        rules.setFont(font);
        rules.setEnabled(false);
        rules.setOpaque(true); 
        rules.addMouseMotionListener(new MouseAdapter(){
                public void mouseMoved(MouseEvent e) {
                    rules.setToolTipText("<html>1.Click to choose the square;<br>2.If you choose bomb, game over");
                }
            });

        //Set the difficulity choose button
        level.setFont(font);
        level.addItem("Level");
        level.addItem("Easy");
        level.addItem("Normal");
        level.addItem("Hard");
        level.addItemListener(new ItemListener(){
                public void itemStateChanged(ItemEvent e) {
                    frame.setVisible(false);
                    if(e.getItem().equals("Easy"))
                    {
                        GameBoard newA = new GameBoard("BombSweeper", 20,20);
                    }else if(e.getItem().equals("Normal")){
                        GameBoard newB = new GameBoard("BombSweeper", 25,25);
                    }else if(e.getItem().equals("Hard")){
                        GameBoard newC = new GameBoard("BombSweeper", 30,30);
                    }
                }
            });

        //Add revelent contents
        titlePanel.add(level);
        titlePanel.add(restart);

        downPanel.add(calTime);
        downPanel.add(rules);

        frame.add("North", titlePanel);
        frame.add("South", downPanel);
    }

    /**
     * Returns the GameSquare instance at a given location. 
     * @param x the x co-ordinate of the square requested.
     * @param y the y co-ordinate of the square requested.
     * @return the GameSquare instance at a given location 
     * if the x and y co-ordinates are valid - null otherwise. 
     */
    public GameSquare getSquareAt(int x, int y)
    {
        if (x < 0 || x >= boardWidth || y < 0 || y >= boardHeight)
            return null;

        return board[x][y];
    }
    
    /**Overload the method*/
    public void actionPerformed(ActionEvent e)
    {
        // The button that has been pressed.
        GameSquare b = (GameSquare)e.getSource();
        b.clicked();
    }

    /**Return the height of it */
    public int getHeight()
    {
        return boardHeight;
    }
    
    /**Return the width of it */
    public int getWidth()
    {
        return boardWidth;
    }
}
