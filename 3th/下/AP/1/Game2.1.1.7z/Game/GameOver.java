import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;

/** This class is used to show the 'Game over' Interface
  * @author Sang Haotian
  */
public class GameOver extends JFrame
{
    private JPanel overPanel = new JPanel(); //Build the main panel
    private JLabel title = new JLabel("Game Over!",SwingConstants.CENTER); //Build the title
    private JButton over = new JButton("Close All Windows"); //Build the closing button

    public void over()
    {
        Font font = new Font("Arial", Font.BOLD, 20); //Setting the font
        title.setFont(new Font("Arial", Font.BOLD, 28));
        over.setFont(new Font("Consolas", Font.BOLD, 20));

        //Setting the futures of title part
        title.setForeground(new Color(139,0,0));
        title.setBackground(new Color(255,228,225));
        title.setOpaque(true);

        //Setting the futures of panel
        overPanel.setBackground(new Color(255,255,205));
        overPanel.add(over,BorderLayout.CENTER);

        //Setting the Interface 
        this.add(title,BorderLayout.NORTH);
        this.add(overPanel);
        this.setTitle("Over");
        this.setSize(400,150);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
        this.repaint();

        //Setting the action when click the button
        over.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    System.exit(0); //Closing the window
                }
            });
    }
}
