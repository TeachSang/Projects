import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import org.apache.poi.xssf.usermodel.*;
import java.util.HashMap;

/** This class is used to build driver, 
 * which drive the add, search, delete methods in arrylists
 * @author Sang Haotian
 */
public class Driver_Hashmap {
	public static int listLength = 1000000; //The length of list
	private static int nameNum = 0;	//The sequence of name

	public static void main(String[] args) throws IOException {
		HashMap<Integer,Person> map = new HashMap<Integer,Person>(); 
		long[] values = new long[1000]; //The array to store the time

		//To call add method 
		int m=0;
		for (int j = 0; j < 1000; j++) {
			values[j] = addElements(map,m);
			m+=100;
		}		
		getXSSFWorkbook("The cost of time", "Addtime", values,"D:/ѧϰ/��ҵ/����/��/AP/2/add.xlsx");
		
		//To call search method 
		/*int m=0;
		for (int j = 0; j < 1000; j++) {
			values[j] = search(map, m);
			m+=1000;
		}
		getXSSFWorkbook("The cost of time", "search time", values,"D:/ѧϰ/��ҵ/����/��/AP/2/search.xlsx");*/
		
		/*/To call delete method 
		/int m=0;
		for (int j = 0; j < 1000; j++) {
			values[j] = delete(map, m);
			m+=1000;
		}
		getXSSFWorkbook("The cost of time", "Delete time", values,"D:/ѧϰ/��ҵ/����/��/AP/2/delete.xlsx");*/	
	}

	/**Create the whole HashMap (1 million contents) */
	public static void create(HashMap<Integer,Person> map) {
		for (int i = 0; i <= listLength; i++) {
			map.put(i,new Person(randomName(), randomAge()));
		}
	}

	/**Create the add method HashMap, which has two models
	 * add one by one
	 * add a group of contents at same time 
	 */
	public static long addElements(HashMap<Integer,Person> map,int time) {
		long startTime = System.nanoTime();

		//map.put(time,new Person(randomName(), randomAge()));		
		for (int i = 0; i < time; i++) {
			map.put(time,new Person(randomName(), randomAge()));
		}
		
		long consumingTime = System.nanoTime() - startTime;
		return consumingTime/1000;
	}

	/**Create the search method HashMap, which has two models
	 * search one by one
	 * search a group of contents at same time 
	 */
	public static long search(HashMap<Integer,Person> map, int time) {
		long startTime = System.nanoTime();
		
		for (int i = 0; i < time*100; i=i+100) {
			HashMap<Integer,Person> o = new HashMap<Integer,Person>(time);
			map.containsKey(o);
		}
		//HashMap<Integer,Person> o = new HashMap<Integer,Person>(time);
		//map.containsKey(o);
		long consumingTime = System.nanoTime() - startTime;
		return consumingTime;
	}

	/**Create the delete method HashMap, which has two models
	 * delete one by one
	 * delete a group of contents at same time 
	 */
	public static long delete(HashMap<Integer,Person> map, int time) {
		long startTime = System.nanoTime();

		for (int i = 0; i < time*100; i=i+100) {
			HashMap<Integer,Person> o = new HashMap<Integer,Person>(time);
			map.remove(o);
		}
		//HashMap<Integer,Person> o = new HashMap<Integer,Person>(time);
		//map.remove(o);

		long consumingTime = System.nanoTime() - startTime;
		return consumingTime/1000;
	}

	/**
	 * Create an excel chart
	 * @param sheetName
	 * @param title
	 * @param values
	 * @param wb
	 * @return
	 * @throws IOException
	 */
	public static void getXSSFWorkbook(String sheetName, String title, long[] values,String fileName) throws IOException {

		FileOutputStream out = new FileOutputStream(new File(fileName));
		// reate a HSSFWorkbook
		XSSFWorkbook wb = new XSSFWorkbook();

		// Create a sheet
		XSSFSheet sheet = wb.createSheet(sheetName);

		// Create the 0 row
		XSSFRow row = sheet.createRow(0);
		XSSFCell cell = null;

		// Create title
		cell = row.createCell(0);
		cell.setCellValue(title);

		// Create contents
		for (int i = 0; i < values.length; i++) {
			row = sheet.createRow(i + 1);
			row.createCell(0).setCellValue(values[i]);
		}
		wb.write(out);
		out.close();
		wb.close();
	}

	/**
	 * Create random names and random ages
	 * @return
	 */
	public static int randomAge() {
		int age = 16;
		return age;
	}

	public static String randomName() {
		String name = "Tom";		
		name = name + nameNum;
		nameNum+=1;
		
		return name;
	}

}
