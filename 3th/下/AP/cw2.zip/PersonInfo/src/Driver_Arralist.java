import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import org.apache.poi.xssf.usermodel.*;

/** This class is used to build driver, 
 * which drive the add, search, delete methods in Arrylists
 * @author Sang Haotian
 */
public class Driver_Arralist {
	public static int listLength = 1000000; //The length of list
	private static int nameNum = 0; //The sequence of name

	public static void main(String[] args) throws IOException {
		ArrayList<Person> list = new ArrayList<Person>();
		long[] values = new long[1000]; //The array to store the time
		
		//To call add method 
		int m=0;
		for (int j = 0; j < 1000; j++) {
			values[j] = addElements(list,m);
			m+=1000;
		}		
		getXSSFWorkbook("The cost of time", "Addtime", values,"D:/ѧϰ/��ҵ/����/��/AP/2/add.xlsx");
		
		//To call search method 
		/*create(list);
		int m=0;
		for (int j = 0; j < 1000; j++) {
			values[j] = search(list, m);
			m+=100;
		}
		getXSSFWorkbook("The cost of time", "search time", values,"D:/ѧϰ/��ҵ/����/��/AP/2/search.xlsx");*/
		
		//To call delete method 
		/*create(list);
		int m=0;
		for (int j = 0; j < 1000; j++) {
			values[j] = delete(list, m);
			m++;
		}
		getXSSFWorkbook("The cost of time", "Delete time", values,"D:/ѧϰ/��ҵ/����/��/AP/2/delete.xlsx");*/
	}

	/**Create the whole Arraylist (1 million contents) */
	public static void create(ArrayList<Person> list) {
		for (int i = 0; i <= listLength; i++) {
			Person p = new Person(randomName(), randomAge());
			list.add(p);
		}
	}
	
	/**Create the add method Arraylist, which has two models
	 * add one by one
	 * add a group of contents at same time 
	 */
	public static long addElements(ArrayList<Person> list,int time) {
		long startTime = System.nanoTime();
		String a = "Tom";
		//list.add(new Person(randomName(), randomAge()));
		for (int i = 0; i < time; i=i+100) {
			System.out.println(i);
			list.add(new Person(a + i, i));
		}

		long consumingTime = System.nanoTime() - startTime;
		return consumingTime;
	}

	/**Create the search method Arraylist, which has two models
	 * search one by one
	 * search a group of contents at same time 
	 */
	public static long search(ArrayList<Person> list, int time) {
		long startTime = System.nanoTime();
		String a = "Tom";

		for (int i = 0; i < time; i=i+100) {
			Person o = new Person(a + i, i);
			list.contains(o);
		}
		//Person o = new Person(a + time, time);
		//list.contains(o);
		long consumingTime = System.nanoTime() - startTime;
		return consumingTime / 1000;
	}

	/**Create the delete method Arraylist, which has two models
	 * delete one by one
	 * delete a group of contents at same time 
	 */
	public static long delete(ArrayList<Person> list, int time) {
		long startTime = System.nanoTime();
		String a = "Tom";

		for (int i = 0; i<time; i=i+100) {
			Person o = new Person(a + i, i);
			list.remove(o);
		}
		//Person o = new Person(a + time, time);
		//list.remove(o);

		long consumingTime = System.nanoTime() - startTime;
		return consumingTime / 1000;
	}

	/**
	 * Create an excel chart
	 * @param sheetName
	 * @param title
	 * @param values
	 * @param wb
	 * @return
	 * @throws IOException
	 */
	public static void getXSSFWorkbook(String sheetName, String title, long[] values,String fileName) throws IOException {

		FileOutputStream out = new FileOutputStream(new File(fileName));
		// Create a HSSFWorkbook
		XSSFWorkbook wb = new XSSFWorkbook();

		// Create a sheet
		XSSFSheet sheet = wb.createSheet(sheetName);

		// Create the 0 row
		XSSFRow row = sheet.createRow(0);
		XSSFCell cell = null;

		// Create title
		cell = row.createCell(0);
		cell.setCellValue(title);

		// Create contents
		for (int i = 0; i < values.length; i++) {
			row = sheet.createRow(i + 1);
			row.createCell(0).setCellValue(values[i]);
		}
		wb.write(out);
		out.close();
		wb.close();
	}

	/**
	 * Create random names and random ages
	 * @return
	 */
	public static int randomAge() {
		int age = 16;
		return age;
	}

	public static String randomName() {
		String name = "Tom";		
		name = name + nameNum;
		nameNum+=1;
		
		return name;
	}

}
